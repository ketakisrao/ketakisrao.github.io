# Usage :  
  
Use for convert and split `*.ttc` file into `*.ttf` files  

# How to use :

> python ttc2ttf.py [TTC_file_Path]

